#################################
# participant 41i
# fit logistic regression model.
logregp41i <- glm(answer ~ step, family=binomial(link="logit"), data=p41i)

# define new data frame that contains predictor variable
logregp41iframe <- data.frame(step=seq(min(p41i$step), max(p41i$step), len=500))

# use fitted model to predict values of dependent variables
logregp41iframe$answer = predict(logregp41i, logregp41iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p41i, col="steelblue")
lines(answer ~ step, logregp41iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp41i)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp41i) [1])/(coef(logregp41i) [2])
#################################


#################################
# participant 43i
# fit logistic regression model.
logregp43i <- glm(answer ~ step, family=binomial(link="logit"), data=p43i)

# define new data frame that contains predictor variable
logregp43iframe <- data.frame(step=seq(min(p43i$step), max(p43i$step), len=500))

# use fitted model to predict values of dependent variables
logregp43iframe$answer = predict(logregp43i, logregp43iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p43i, col="steelblue")
lines(answer ~ step, logregp43iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp43i)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp43i) [1])/(coef(logregp43i) [2])
#################################


#################################
# participant 45i
# fit logistic regression model.
logregp45i <- glm(answer ~ step, family=binomial(link="logit"), data=p45i)

# define new data frame that contains predictor variable
logregp45iframe <- data.frame(step=seq(min(p45i$step), max(p45i$step), len=500))

# use fitted model to predict values of dependent variables
logregp45iframe$answer = predict(logregp45i, logregp45iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p45i, col="steelblue")
lines(answer ~ step, logregp45iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp45i)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp45i) [1])/(coef(logregp45i) [2])
#################################


#################################
# participant 46i
# fit logistic regression model.
logregp46i <- glm(answer ~ step, family=binomial(link="logit"), data=p46i)

# define new data frame that contains predictor variable
logregp46iframe <- data.frame(step=seq(min(p46i$step), max(p46i$step), len=500))

# use fitted model to predict values of dependent variables
logregp46iframe$answer = predict(logregp46i, logregp46iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p46i, col="steelblue")
lines(answer ~ step, logregp46iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp46i)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp46i) [1])/(coef(logregp46i) [2])
#################################


#################################
# participant 48i
# fit logistic regression model.
logregp48i <- glm(answer ~ step, family=binomial(link="logit"), data=p48i)

# define new data frame that contains predictor variable
logregp48iframe <- data.frame(step=seq(min(p48i$step), max(p48i$step), len=500))

# use fitted model to predict values of dependent variables
logregp48iframe$answer = predict(logregp48i, logregp48iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p48i, col="steelblue")
lines(answer ~ step, logregp48iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp48i)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp48i) [1])/(coef(logregp48i) [2])
#################################


#################################
# participant 49i
# fit logistic regression model.
logregp49i <- glm(answer ~ step, family=binomial(link="logit"), data=p49i)

# define new data frame that contains predictor variable
logregp49iframe <- data.frame(step=seq(min(p49i$step), max(p49i$step), len=500))

# use fitted model to predict values of dependent variables
logregp49iframe$answer = predict(logregp49i, logregp49iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p49i, col="steelblue")
lines(answer ~ step, logregp49iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp49i)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp49i) [1])/(coef(logregp49i) [2])
#################################


#################################
# participant 50i
# fit logistic regression model.
logregp50i <- glm(answer ~ step, family=binomial(link="logit"), data=p50i)

# define new data frame that contains predictor variable
logregp50iframe <- data.frame(step=seq(min(p50i$step), max(p50i$step), len=500))

# use fitted model to predict values of dependent variables
logregp50iframe$answer = predict(logregp50i, logregp50iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p50i, col="steelblue")
lines(answer ~ step, logregp50iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp50i)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp50i) [1])/(coef(logregp50i) [2])
#################################


#################################
# participant 41u
# fit logistic regression model.
logregp41u <- glm(answer ~ step, family=binomial(link="logit"), data=p41u)

# define new data frame that contains predictor variable
logregp41uframe <- data.frame(step=seq(min(p41u$step), max(p41u$step), len=500))

# use fitted model to predict values of dependent variables
logregp41uframe$answer = predict(logregp41u, logregp41uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p41u, col="steelblue")
lines(answer ~ step, logregp41uframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp41u)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp41u) [1])/(coef(logregp41u) [2])
#################################


#################################
# participant 43u
# fit logistic regression model.
logregp43u <- glm(answer ~ step, family=binomial(link="logit"), data=p43u)

# define new data frame that contains predictor variable
logregp43uframe <- data.frame(step=seq(min(p43u$step), max(p43u$step), len=500))

# use fitted model to predict values of dependent variables
logregp43uframe$answer = predict(logregp43u, logregp43uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p43u, col="steelblue")
lines(answer ~ step, logregp43uframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp43u)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp43u) [1])/(coef(logregp43u) [2])
#################################


#################################
# participant 45u
# fit logistic regression model.
logregp45u <- glm(answer ~ step, family=binomial(link="logit"), data=p45u)

# define new data frame that contains predictor variable
logregp45uframe <- data.frame(step=seq(min(p45u$step), max(p45u$step), len=500))

# use fitted model to predict values of dependent variables
logregp45uframe$answer = predict(logregp45u, logregp45uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p45u, col="steelblue")
lines(answer ~ step, logregp45uframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp45u)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp45u) [1])/(coef(logregp45u) [2])
#################################


#################################
# participant 46u
# fit logistic regression model.
logregp46u <- glm(answer ~ step, family=binomial(link="logit"), data=p46u)

# define new data frame that contains predictor variable
logregp46uframe <- data.frame(step=seq(min(p46u$step), max(p46u$step), len=500))

# use fitted model to predict values of dependent variables
logregp46uframe$answer = predict(logregp46u, logregp46uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p46u, col="steelblue")
lines(answer ~ step, logregp46uframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp46u)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp46u) [1])/(coef(logregp46u) [2])
#################################


#################################
# participant 48u
# fit logistic regression model.
logregp48u <- glm(answer ~ step, family=binomial(link="logit"), data=p48u)

# define new data frame that contains predictor variable
logregp48uframe <- data.frame(step=seq(min(p48u$step), max(p48u$step), len=500))

# use fitted model to predict values of dependent variables
logregp48uframe$answer = predict(logregp48u, logregp48uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p48u, col="steelblue")
lines(answer ~ step, logregp48uframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp48u)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp48u) [1])/(coef(logregp48u) [2])
#################################


#################################
# participant 49u
# fit logistic regression model.
logregp49u <- glm(answer ~ step, family=binomial(link="logit"), data=p49u)

# define new data frame that contains predictor variable
logregp49uframe <- data.frame(step=seq(min(p49u$step), max(p49u$step), len=500))

# use fitted model to predict values of dependent variables
logregp49uframe$answer = predict(logregp49u, logregp49uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p49u, col="steelblue")
lines(answer ~ step, logregp49uframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp49u)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp49u) [1])/(coef(logregp49u) [2])
#################################


#################################
# participant 50u
# fit logistic regression model.
logregp50u <- glm(answer ~ step, family=binomial(link="logit"), data=p50u)

# define new data frame that contains predictor variable
logregp50uframe <- data.frame(step=seq(min(p50u$step), max(p50u$step), len=500))

# use fitted model to predict values of dependent variables
logregp50uframe$answer = predict(logregp50u, logregp50uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p50u, col="steelblue")
lines(answer ~ step, logregp50uframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp50u)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp50u) [1])/(coef(logregp50u) [2])
#################################