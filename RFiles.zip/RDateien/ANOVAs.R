# linear mixed regression model
# dep var = catbound
# ind var = group, deuscore, engscore
# random effects = participant



# first data set: SumENGgru
# write out linear regression model, all variables
allSumENGgru = lm(formula=catbound ~ group + engscore + deuscore, data=SumENGgru)

# lm model, null hypothesis
nullSumENGgru = lm(formula=catbound ~ 1, data=SumENGgru)

# lm model , group only
m1SumENGgru = lm(formula=catbound ~ group, data=SumENGgru)

# lm model, engscore only
m2SumENGgru = lm(formula=catbound ~ engscore, data=SumENGgru)

# lm model, deuscore only
m3SumENGgru = lm(formula=catbound ~ deuscore, data=SumENGgru)

# lm model, group + engscore
m4SumENGgru = lm(formula=catbound ~ group + engscore, data=SumENGgru)

# lm model, group + deuscore
m5SumENGgru = lm(formula=catbound ~ group + deuscore, data=SumENGgru)



### Tests to see if this is the right model
# Get the model residuals
model_residuals = lmSumENGgru$residuals

# Plot the result
hist(model_residuals)

# Plot the residuals
qqnorm(model_residuals)
# Plot the Q-Q line
qqline(model_residuals)

# Install and load the ggcorrplot package
install.packages("ggcorrplot")
library(ggcorrplot)

# Remove the Customer Value column
reduced_data <- subset(SumENGgru, select = -catbound)

# Compute correlation at 2 decimal places
corr_matrix = round(cor(reduced_data), 2)

# Compute and show the  result
ggcorrplot(corr_matrix, hc.order = TRUE, type = "lower",
           lab = TRUE)



# ANOVA tests
anova(nullSumENGgru, m1SumENGgru, m2SumENGgru, m3SumENGgru, m4SumENGgru, m5SumENGgru, allSumENGgru)



# second data set: SumENGgri
# write out linear regression model, all variables
allSumENGgri = lm(formula=catbound ~ group + engscore + deuscore, data=SumENGgri)

# lm model, null hypothesis
nullSumENGgri = lm(formula=catbound ~ 1, data=SumENGgri)

# lm model , group only
m1SumENGgri = lm(formula=catbound ~ group, data=SumENGgri)

# lm model, engscore only
m2SumENGgri = lm(formula=catbound ~ engscore, data=SumENGgri)

# lm model, deuscore only
m3SumENGgri = lm(formula=catbound ~ deuscore, data=SumENGgri)

# lm model, group + engscore
m4SumENGgri = lm(formula=catbound ~ group + engscore, data=SumENGgri)

# lm model, group + deuscore
m5SumENGgri = lm(formula=catbound ~ group + deuscore, data=SumENGgri)



### Tests to see if this is the right model
# Get the model residuals
model_residuals = allSumENGgri$residuals

# Plot the result
hist(model_residuals)

# Plot the residuals
qqnorm(model_residuals)
# Plot the Q-Q line
qqline(model_residuals)

# Remove the Customer Value column
reduced_data <- subset(SumENGgri, select = -catbound)

# Compute correlation at 2 decimal places
corr_matrix = round(cor(reduced_data), 2)

# Compute and show the  result
ggcorrplot(corr_matrix, hc.order = TRUE, type = "lower",
           lab = TRUE)



# ANOVA tests
anova(nullSumENGgri, m1SumENGgri, m2SumENGgri, m3SumENGgri, m4SumENGgri, m5SumENGgri, allSumENGgri)

