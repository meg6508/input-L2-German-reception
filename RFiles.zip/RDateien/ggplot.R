# Graph using ggplot
library(tidyverse)

### Example / Test on group data
# run logistic regression on all group data for GER[i]
# fit logistic regression model.
logregGERgri <- glm(answer ~ step, family=binomial(link="logit"), data=GERgri)

# define new data frame that contains predictor variable
logregGERgriframe <- data.frame(step=seq(min(GERgri$step), max(GERgri$step), len=500))

# ggplot2
library(ggplot2)

ggplot(logregGERgri, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="red", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=p41i, method="glm", color="lightgray", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p43i, method="glm", color="lightgray", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p45i, method="glm", color="lightgray", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p46i, method="glm", color="lightgray", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p48i, method="glm", color="lightgray", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p49i, method="glm", color="lightgray", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p50i, method="glm", color="lightgray", se=FALSE, method.args = list(family=binomial))

# trial with group data comparisons i
ggplot(logregENGgrHi, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="coral", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=ENGgrNi, method="glm", color="cornflowerblue", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=GERgri, method="glm", color="black", se=FALSE, method.args = list(family=binomial))

# trial with group data comparisons u
ggplot(logregENGgrHu, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="coral", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=ENGgrNu, method="glm", color="cornflowerblue", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=GERgru, method="glm", color="black", se=FALSE, method.args = list(family=binomial))

# for some reason stat_smooth did not work
stat_smooth(method="glm", color="limegreen", se=FALSE, method.args = list(family=binomial))

# Let's try corrected graph then
ggplot(logregENGgrHi, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="coral", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=ENGgrNi, method="glm", color="cornflowerblue", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=CORR, method="glm", color="black", se=FALSE, method.args = list(family=binomial))
#############                                                 
# fit logistic regressions we need for GERi
# participant 41i
# fit logistic regression model.
logregp41i <- glm(answer ~ step, family=binomial(link="logit"), data=p41i)

# participant 43i
# fit logistic regression model.
logregp43i <- glm(answer ~ step, family=binomial(link="logit"), data=p43i)

# participant 45i
# fit logistic regression model.
logregp45i <- glm(answer ~ step, family=binomial(link="logit"), data=p45i)

# participant 46i
# fit logistic regression model.
logregp46i <- glm(answer ~ step, family=binomial(link="logit"), data=p46i)

# participant 48i
# fit logistic regression model.
logregp48i <- glm(answer ~ step, family=binomial(link="logit"), data=p48i)

# participant 49i
# fit logistic regression model.
logregp49i <- glm(answer ~ step, family=binomial(link="logit"), data=p49i)

# participant 50i
# fit logistic regression model.
logregp50i <- glm(answer ~ step, family=binomial(link="logit"), data=p50i)



# GERi aggregate data
ggplot(logregp41i, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=p43i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p45i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p46i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p48i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p49i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p50i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=GERgri, method="glm", color="black", se=FALSE, method.args = list(family=binomial))

# GERu aggregate data
ggplot(logregp41u, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=p43u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p45u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p46u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p48u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p49u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p50u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=GERgru, method="glm", color="black", se=FALSE, method.args = list(family=binomial))

# ENGNi aggregate data
ggplot(logregp4i, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=p5i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p7i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p9i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p13i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p15i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p20i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p21i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p23i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p24i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p25i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p28i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p29i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p31i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=ENGgrNi, method="glm", color="black", se=FALSE, method.args = list(family=binomial))
  
# ENGNu aggregate data
ggplot(logregp4u, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=p5u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p7u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p9u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p13u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p15u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p20u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p21u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p23u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p24u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p25u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p28u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p29u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p31u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=ENGgrNu, method="glm", color="black", se=FALSE, method.args = list(family=binomial))

# ENGHi aggregate data
ggplot(logregp1i, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=p2i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p3i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p6i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p8i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p10i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p11i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p12i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p14i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p17i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p18i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p19i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p22i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p26i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p27i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p30i, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=ENGgrHi, method="glm", color="black", se=FALSE, method.args = list(family=binomial))

# ENGHu aggregate data
ggplot(logregp1u, aes(x=step, y=answer)) + 
  geom_smooth(method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) + 
  geom_smooth(data=p2u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p3u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p6u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p8u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p10u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p11u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p12u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p14u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p17u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p18u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p19u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p22u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p26u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p27u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=p30u, method="glm", color="cornsilk3", se=FALSE, method.args = list(family=binomial)) +
  geom_smooth(data=ENGgrHu, method="glm", color="black", se=FALSE, method.args = list(family=binomial))
