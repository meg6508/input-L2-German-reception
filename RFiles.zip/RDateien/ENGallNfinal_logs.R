#################################
# participant 41i
# fit logistic regression model.
logregp41i <- glm(answer ~ step, family=binomial(link="logit"), data=p41i)

# define new data frame that contains predictor variable
logregp41iframe <- data.frame(step=seq(min(p41i$step), max(p41i$step), len=500))

# use fitted model to predict values of dependent variables
logregp41iframe$answer = predict(logregp41i, logregp41iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p41i, col="steelblue")
lines(answer ~ step, logregp41iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp41i)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp41i) [1])/(coef(logregp41i) [2])
#################################