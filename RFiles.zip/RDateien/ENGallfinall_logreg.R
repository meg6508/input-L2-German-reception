######### ENGindNi
# participant 4i
# fit logistic regression model.
logregp4i <- glm(answer ~ step, family=binomial(link="logit"), data=p4i)

# define new data frame that contains predictor variable
logregp4iframe <- data.frame(step=seq(min(p4i$step), max(p4i$step), len=500))

# use fitted model to predict values of dependent variables
logregp4iframe$answer = predict(logregp4i, logregp4iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p4i, col="steelblue")
lines(answer ~ step, logregp4iframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregp4u)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp4i) [1])/(coef(logregp4i) [2])
#########
# participant 5i
# fit logistic regression model.
logregp5i <- glm(answer ~ step, family=binomial(link="logit"), data=p5i)

# define new data frame that contains predictor variable
logregp5iframe <- data.frame(step=seq(min(p5i$step), max(p5i$step), len=500))

# use fitted model to predict values of dependent variables
logregp5iframe$answer = predict(logregp5i, logregp5iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p5i, col="steelblue")
lines(answer ~ step, logregp5iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp5i) [1])/(coef(logregp5i) [2])

#########
# participant 7i
# fit logistic regression model.
logregp7i <- glm(answer ~ step, family=binomial(link="logit"), data=p7i)

# define new data frame that contains predictor variable
logregp7iframe <- data.frame(step=seq(min(p7i$step), max(p7i$step), len=500))

# use fitted model to predict values of dependent variables
logregp7iframe$answer = predict(logregp7i, logregp7iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p7i, col="steelblue")
lines(answer ~ step, logregp7iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp7i) [1])/(coef(logregp7i) [2])
#########
# participant 9i
# fit logistic regression model.
logregp9i <- glm(answer ~ step, family=binomial(link="logit"), data=p9i)

# define new data frame that contains predictor variable
logregp9iframe <- data.frame(step=seq(min(p9i$step), max(p9i$step), len=500))

# use fitted model to predict values of dependent variables
logregp9iframe$answer = predict(logregp9i, logregp9iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p9i, col="steelblue")
lines(answer ~ step, logregp9iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp9i) [1])/(coef(logregp9i) [2])
#########
# participant 13i
# fit logistic regression model.
logregp13i <- glm(answer ~ step, family=binomial(link="logit"), data=p13i)

# define new data frame that contains predictor variable
logregp13iframe <- data.frame(step=seq(min(p13i$step), max(p13i$step), len=500))

# use fitted model to predict values of dependent variables
logregp13iframe$answer = predict(logregp13i, logregp13iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p13i, col="steelblue")
lines(answer ~ step, logregp13iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp9i) [1])/(coef(logregp9i) [2])
#########
# participant 15i
# fit logistic regression model.
logregp15i <- glm(answer ~ step, family=binomial(link="logit"), data=p15i)

# define new data frame that contains predictor variable
logregp15iframe <- data.frame(step=seq(min(p15i$step), max(p15i$step), len=500))

# use fitted model to predict values of dependent variables
logregp15iframe$answer = predict(logregp15i, logregp15iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p15i, col="steelblue")
lines(answer ~ step, logregp15iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp15i) [1])/(coef(logregp15i) [2])
#########
# participant 20i
# fit logistic regression model.
logregp20i <- glm(answer ~ step, family=binomial(link="logit"), data=p20i)

# define new data frame that contains predictor variable
logregp20iframe <- data.frame(step=seq(min(p20i$step), max(p20i$step), len=500))

# use fitted model to predict values of dependent variables
logregp20iframe$answer = predict(logregp20i, logregp20iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p20i, col="steelblue")
lines(answer ~ step, logregp20iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp20i) [1])/(coef(logregp20i) [2])
#########
# participant 21i
# fit logistic regression model.
logregp21i <- glm(answer ~ step, family=binomial(link="logit"), data=p21i)

# define new data frame that contains predictor variable
logregp21iframe <- data.frame(step=seq(min(p21i$step), max(p21i$step), len=500))

# use fitted model to predict values of dependent variables
logregp21iframe$answer = predict(logregp21i, logregp21iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p21i, col="steelblue")
lines(answer ~ step, logregp21iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp21i) [1])/(coef(logregp21i) [2])
#########
# participant 23i
# fit logistic regression model.
logregp23i <- glm(answer ~ step, family=binomial(link="logit"), data=p23i)

# define new data frame that contains predictor variable
logregp23iframe <- data.frame(step=seq(min(p23i$step), max(p23i$step), len=500))

# use fitted model to predict values of dependent variables
logregp23iframe$answer = predict(logregp23i, logregp23iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p23i, col="steelblue")
lines(answer ~ step, logregp23iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp23i) [1])/(coef(logregp23i) [2])
#########
# participant 24i
# fit logistic regression model.
logregp24i <- glm(answer ~ step, family=binomial(link="logit"), data=p24i)

# define new data frame that contains predictor variable
logregp24iframe <- data.frame(step=seq(min(p24i$step), max(p24i$step), len=500))

# use fitted model to predict values of dependent variables
logregp24iframe$answer = predict(logregp24i, logregp24iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p24i, col="steelblue")
lines(answer ~ step, logregp24iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp24i) [1])/(coef(logregp24i) [2])
#########
# participant 25i
# fit logistic regression model.
logregp25i <- glm(answer ~ step, family=binomial(link="logit"), data=p25i)

# define new data frame that contains predictor variable
logregp25iframe <- data.frame(step=seq(min(p25i$step), max(p25i$step), len=500))

# use fitted model to predict values of dependent variables
logregp25iframe$answer = predict(logregp25i, logregp25iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p25i, col="steelblue")
lines(answer ~ step, logregp25iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp25i) [1])/(coef(logregp25i) [2])
#########
# participant 28i
# fit logistic regression model.
logregp28i <- glm(answer ~ step, family=binomial(link="logit"), data=p28i)

# define new data frame that contains predictor variable
logregp28iframe <- data.frame(step=seq(min(p28i$step), max(p28i$step), len=500))

# use fitted model to predict values of dependent variables
logregp28iframe$answer = predict(logregp28i, logregp28iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p28i, col="steelblue")
lines(answer ~ step, logregp28iframe, lwd=2)


# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp28i) [1])/(coef(logregp28i) [2])
#########
# participant 29i
# fit logistic regression model.
logregp29i <- glm(answer ~ step, family=binomial(link="logit"), data=p29i)

# define new data frame that contains predictor variable
logregp29iframe <- data.frame(step=seq(min(p29i$step), max(p29i$step), len=500))

# use fitted model to predict values of dependent variables
logregp29iframe$answer = predict(logregp29i, logregp29iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p29i, col="steelblue")
lines(answer ~ step, logregp29iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp29i) [1])/(coef(logregp29i) [2])
#########
# participant 31i
# fit logistic regression model.
logregp31i <- glm(answer ~ step, family=binomial(link="logit"), data=p31i)

# define new data frame that contains predictor variable
logregp31iframe <- data.frame(step=seq(min(p31i$step), max(p31i$step), len=500))

# use fitted model to predict values of dependent variables
logregp31iframe$answer = predict(logregp31i, logregp31iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p31i, col="steelblue")
lines(answer ~ step, logregp31iframe, lwd=2)


# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp31i) [1])/(coef(logregp31i) [2])
#################################
#################################
#################################

######### ENGindNu
# participant 4u
# fit logistic regression model.
logregp4u <- glm(answer ~ step, family=binomial(link="logit"), data=p4u)

# define new data frame that contains predictor variable
logregp4uframe <- data.frame(step=seq(min(p4u$step), max(p4u$step), len=500))

# use fitted model to predict values of dependent variables
logregp4uframe$answer = predict(logregp4u, logregp4uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p4u, col="steelblue")
lines(answer ~ step, logregp4uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp4u) [1])/(coef(logregp4u) [2])
#########
# participant 5i
# fit logistic regression model.
logregp5u <- glm(answer ~ step, family=binomial(link="logit"), data=p5u)

# define new data frame that contains predictor variable
logregp5uframe <- data.frame(step=seq(min(p5u$step), max(p5u$step), len=500))

# use fitted model to predict values of dependent variables
logregp5uframe$answer = predict(logregp5u, logregp5uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p5u, col="steelblue")
lines(answer ~ step, logregp5uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp5u) [1])/(coef(logregp5u) [2])
#########
# participant 7u
# fit logistic regression model.
logregp7u <- glm(answer ~ step, family=binomial(link="logit"), data=p7u)

# define new data frame that contains predictor variable
logregp7uframe <- data.frame(step=seq(min(p7u$step), max(p7u$step), len=500))

# use fitted model to predict values of dependent variables
logregp7uframe$answer = predict(logregp7u, logregp7uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p7u, col="steelblue")
lines(answer ~ step, logregp7uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp7u) [1])/(coef(logregp7u) [2])
#########
# participant 9u
# fit logistic regression model.
logregp9u <- glm(answer ~ step, family=binomial(link="logit"), data=p9u)

# define new data frame that contains predictor variable
logregp9uframe <- data.frame(step=seq(min(p9u$step), max(p9u$step), len=500))

# use fitted model to predict values of dependent variables
logregp9uframe$answer = predict(logregp9u, logregp9uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p9u, col="steelblue")
lines(answer ~ step, logregp9uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp9u) [1])/(coef(logregp9u) [2])
#########
# participant 13u
# fit logistic regression model.
logregp13u <- glm(answer ~ step, family=binomial(link="logit"), data=p13u)

# define new data frame that contains predictor variable
logregp13uframe <- data.frame(step=seq(min(p13u$step), max(p13u$step), len=500))

# use fitted model to predict values of dependent variables
logregp13uframe$answer = predict(logregp13u, logregp13uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p13u, col="steelblue")
lines(answer ~ step, logregp13uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp13u) [1])/(coef(logregp13u) [2])
#########
# participant 15u
# fit logistic regression model.
logregp15u <- glm(answer ~ step, family=binomial(link="logit"), data=p15u)

# define new data frame that contains predictor variable
logregp15uframe <- data.frame(step=seq(min(p15u$step), max(p15u$step), len=500))

# use fitted model to predict values of dependent variables
logregp15uframe$answer = predict(logregp15u, logregp15uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p15u, col="steelblue")
lines(answer ~ step, logregp15uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp15u) [1])/(coef(logregp15u) [2])
#########
# participant 20u
# fit logistic regression model.
logregp20u <- glm(answer ~ step, family=binomial(link="logit"), data=p20u)

# define new data frame that contains predictor variable
logregp20uframe <- data.frame(step=seq(min(p20u$step), max(p20u$step), len=500))

# use fitted model to predict values of dependent variables
logregp20uframe$answer = predict(logregp20u, logregp20uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p20u, col="steelblue")
lines(answer ~ step, logregp20uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp20u) [1])/(coef(logregp20u) [2])
#########
# participant 21u
# fit logistic regression model.
logregp21u <- glm(answer ~ step, family=binomial(link="logit"), data=p21u)

# define new data frame that contains predictor variable
logregp21uframe <- data.frame(step=seq(min(p21u$step), max(p21u$step), len=500))

# use fitted model to predict values of dependent variables
logregp21uframe$answer = predict(logregp21u, logregp21uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p21u, col="steelblue")
lines(answer ~ step, logregp21uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp21u) [1])/(coef(logregp21u) [2])
#########
# participant 23u
# fit logistic regression model.
logregp23u <- glm(answer ~ step, family=binomial(link="logit"), data=p23u)

# define new data frame that contains predictor variable
logregp23uframe <- data.frame(step=seq(min(p23u$step), max(p23u$step), len=500))

# use fitted model to predict values of dependent variables
logregp23uframe$answer = predict(logregp23u, logregp23uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p23u, col="steelblue")
lines(answer ~ step, logregp23uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp23u) [1])/(coef(logregp23u) [2])
#########
# participant 24u
# fit logistic regression model.
logregp24u <- glm(answer ~ step, family=binomial(link="logit"), data=p24u)

# define new data frame that contains predictor variable
logregp24uframe <- data.frame(step=seq(min(p24u$step), max(p24u$step), len=500))

# use fitted model to predict values of dependent variables
logregp24uframe$answer = predict(logregp24u, logregp24uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p24u, col="steelblue")
lines(answer ~ step, logregp24uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp24u) [1])/(coef(logregp24u) [2])
#########
# participant 25u
# fit logistic regression model.
logregp25u <- glm(answer ~ step, family=binomial(link="logit"), data=p25u)

# define new data frame that contains predictor variable
logregp25uframe <- data.frame(step=seq(min(p25u$step), max(p25u$step), len=500))

# use fitted model to predict values of dependent variables
logregp25uframe$answer = predict(logregp25u, logregp25uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p25u, col="steelblue")
lines(answer ~ step, logregp25uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp25u) [1])/(coef(logregp25u) [2])
#########
# participant 28u
# fit logistic regression model.
logregp28u <- glm(answer ~ step, family=binomial(link="logit"), data=p28u)

# define new data frame that contains predictor variable
logregp28uframe <- data.frame(step=seq(min(p28u$step), max(p28u$step), len=500))

# use fitted model to predict values of dependent variables
logregp28uframe$answer = predict(logregp28u, logregp28uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p28u, col="steelblue")
lines(answer ~ step, logregp28uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp28u) [1])/(coef(logregp28u) [2])
#########
# participant 29u
# fit logistic regression model.
logregp29u <- glm(answer ~ step, family=binomial(link="logit"), data=p29u)

# define new data frame that contains predictor variable
logregp29uframe <- data.frame(step=seq(min(p29u$step), max(p29u$step), len=500))

# use fitted model to predict values of dependent variables
logregp29uframe$answer = predict(logregp29u, logregp29uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p29u, col="steelblue")
lines(answer ~ step, logregp29uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp29u) [1])/(coef(logregp29u) [2])
#########
# participant 31u
# fit logistic regression model.
logregp31u <- glm(answer ~ step, family=binomial(link="logit"), data=p31u)

# define new data frame that contains predictor variable
logregp31uframe <- data.frame(step=seq(min(p31u$step), max(p31u$step), len=500))

# use fitted model to predict values of dependent variables
logregp31uframe$answer = predict(logregp31u, logregp31uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p31u, col="steelblue")
lines(answer ~ step, logregp31uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp31u) [1])/(coef(logregp31u) [2])
#################################
#################################
#################################

######### ENGindHi
# participant 1i
# fit logistic regression model.
logregp1i <- glm(answer ~ step, family=binomial(link="logit"), data=p1i)

# define new data frame that contains predictor variable
logregp1iframe <- data.frame(step=seq(min(p1i$step), max(p1i$step), len=500))

# use fitted model to predict values of dependent variables
logregp1iframe$answer = predict(logregp1i, logregp1iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p1i, col="steelblue")
lines(answer ~ step, logregp1iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp1i) [1])/(coef(logregp1i) [2])

#########
# participant 2i
# fit logistic regression model.
logregp2i <- glm(answer ~ step, family=binomial(link="logit"), data=p2i)

# define new data frame that contains predictor variable
logregp2iframe <- data.frame(step=seq(min(p2i$step), max(p2i$step), len=500))

# use fitted model to predict values of dependent variables
logregp2iframe$answer = predict(logregp2i, logregp2iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p2i, col="steelblue")
lines(answer ~ step, logregp2iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp2i) [1])/(coef(logregp2i) [2])

#########
# participant 3i
# fit logistic regression model.
logregp3i <- glm(answer ~ step, family=binomial(link="logit"), data=p3i)

# define new data frame that contains predictor variable
logregp3iframe <- data.frame(step=seq(min(p3i$step), max(p3i$step), len=500))

# use fitted model to predict values of dependent variables
logregp3iframe$answer = predict(logregp3i, logregp3iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p3i, col="steelblue")
lines(answer ~ step, logregp3iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp3i) [1])/(coef(logregp3i) [2])

#########
# participant 6i
# fit logistic regression model.
logregp6i <- glm(answer ~ step, family=binomial(link="logit"), data=p6i)

# define new data frame that contains predictor variable
logregp6iframe <- data.frame(step=seq(min(p6i$step), max(p6i$step), len=500))

# use fitted model to predict values of dependent variables
logregp6iframe$answer = predict(logregp6i, logregp6iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p6i, col="steelblue")
lines(answer ~ step, logregp6iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp6i) [1])/(coef(logregp6i) [2])

#########
# participant 8i
# fit logistic regression model.
logregp8i <- glm(answer ~ step, family=binomial(link="logit"), data=p8i)

# define new data frame that contains predictor variable
logregp8iframe <- data.frame(step=seq(min(p8i$step), max(p8i$step), len=500))

# use fitted model to predict values of dependent variables
logregp8iframe$answer = predict(logregp8i, logregp8iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p8i, col="steelblue")
lines(answer ~ step, logregp8iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp8i) [1])/(coef(logregp8i) [2])

#########
# participant 10i
# fit logistic regression model.
logregp10i <- glm(answer ~ step, family=binomial(link="logit"), data=p10i)

# define new data frame that contains predictor variable
logregp10iframe <- data.frame(step=seq(min(p10i$step), max(p10i$step), len=500))

# use fitted model to predict values of dependent variables
logregp10iframe$answer = predict(logregp10i, logregp10iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p10i, col="steelblue")
lines(answer ~ step, logregp10iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp10i) [1])/(coef(logregp10i) [2])

#########
# participant 11i
# fit logistic regression model.
logregp11i <- glm(answer ~ step, family=binomial(link="logit"), data=p11i)

# define new data frame that contains predictor variable
logregp11iframe <- data.frame(step=seq(min(p11i$step), max(p11i$step), len=500))

# use fitted model to predict values of dependent variables
logregp11iframe$answer = predict(logregp11i, logregp11iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p11i, col="steelblue")
lines(answer ~ step, logregp11iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp11i) [1])/(coef(logregp11i) [2])

#########
# participant 12i
# fit logistic regression model.
logregp12i <- glm(answer ~ step, family=binomial(link="logit"), data=p12i)

# define new data frame that contains predictor variable
logregp12iframe <- data.frame(step=seq(min(p12i$step), max(p12i$step), len=500))

# use fitted model to predict values of dependent variables
logregp12iframe$answer = predict(logregp12i, logregp12iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p12i, col="steelblue")
lines(answer ~ step, logregp12iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp12i) [1])/(coef(logregp12i) [2])

#########
# participant 14i
# fit logistic regression model.
logregp14i <- glm(answer ~ step, family=binomial(link="logit"), data=p14i)

# define new data frame that contains predictor variable
logregp14iframe <- data.frame(step=seq(min(p14i$step), max(p14i$step), len=500))

# use fitted model to predict values of dependent variables
logregp14iframe$answer = predict(logregp14i, logregp14iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p14i, col="steelblue")
lines(answer ~ step, logregp14iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp14i) [1])/(coef(logregp14i) [2])

#########
# participant 17i
# fit logistic regression model.
logregp17i <- glm(answer ~ step, family=binomial(link="logit"), data=p17i)

# define new data frame that contains predictor variable
logregp17iframe <- data.frame(step=seq(min(p17i$step), max(p17i$step), len=500))

# use fitted model to predict values of dependent variables
logregp17iframe$answer = predict(logregp17i, logregp17iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p17i, col="steelblue")
lines(answer ~ step, logregp17iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp17i) [1])/(coef(logregp17i) [2])

#########
# participant 18i
# fit logistic regression model.
logregp18i <- glm(answer ~ step, family=binomial(link="logit"), data=p18i)

# define new data frame that contains predictor variable
logregp18iframe <- data.frame(step=seq(min(p18i$step), max(p18i$step), len=500))

# use fitted model to predict values of dependent variables
logregp18iframe$answer = predict(logregp18i, logregp18iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p18i, col="steelblue")
lines(answer ~ step, logregp18iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp18i) [1])/(coef(logregp18i) [2])

#########
# participant 19i
# fit logistic regression model.
logregp19i <- glm(answer ~ step, family=binomial(link="logit"), data=p19i)

# define new data frame that contains predictor variable
logregp19iframe <- data.frame(step=seq(min(p19i$step), max(p19i$step), len=500))

# use fitted model to predict values of dependent variables
logregp19iframe$answer = predict(logregp19i, logregp19iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p19i, col="steelblue")
lines(answer ~ step, logregp19iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp19i) [1])/(coef(logregp19i) [2])

#########
# participant 22i
# fit logistic regression model.
logregp22i <- glm(answer ~ step, family=binomial(link="logit"), data=p22i)

# define new data frame that contains predictor variable
logregp22iframe <- data.frame(step=seq(min(p22i$step), max(p22i$step), len=500))

# use fitted model to predict values of dependent variables
logregp22iframe$answer = predict(logregp22i, logregp22iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p22i, col="steelblue")
lines(answer ~ step, logregp22iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp22i) [1])/(coef(logregp22i) [2])

#########
# participant 26i
# fit logistic regression model.
logregp26i <- glm(answer ~ step, family=binomial(link="logit"), data=p26i)

# define new data frame that contains predictor variable
logregp26iframe <- data.frame(step=seq(min(p26i$step), max(p26i$step), len=500))

# use fitted model to predict values of dependent variables
logregp26iframe$answer = predict(logregp26i, logregp26iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p26i, col="steelblue")
lines(answer ~ step, logregp26iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp26i) [1])/(coef(logregp26i) [2])

#########
# participant 27i
# fit logistic regression model.
logregp27i <- glm(answer ~ step, family=binomial(link="logit"), data=p27i)

# define new data frame that contains predictor variable
logregp27iframe <- data.frame(step=seq(min(p27i$step), max(p27i$step), len=500))

# use fitted model to predict values of dependent variables
logregp27iframe$answer = predict(logregp27i, logregp27iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p27i, col="steelblue")
lines(answer ~ step, logregp27iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp27i) [1])/(coef(logregp27i) [2])

#########
# participant 30i
# fit logistic regression model.
logregp30i <- glm(answer ~ step, family=binomial(link="logit"), data=p30i)

# define new data frame that contains predictor variable
logregp30iframe <- data.frame(step=seq(min(p30i$step), max(p30i$step), len=500))

# use fitted model to predict values of dependent variables
logregp30iframe$answer = predict(logregp30i, logregp30iframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p30i, col="steelblue")
lines(answer ~ step, logregp30iframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp30i) [1])/(coef(logregp30i) [2])

#########
######### ENGindHu
# participant 1u
# fit logistic regression model.
logregp1u <- glm(answer ~ step, family=binomial(link="logit"), data=p1u)

# define new data frame that contains predictor variable
logregp1uframe <- data.frame(step=seq(min(p1u$step), max(p1u$step), len=500))

# use fitted model to predict values of dependent variables
logregp1uframe$answer = predict(logregp1u, logregp1uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p1u, col="steelblue")
lines(answer ~ step, logregp1uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp1u) [1])/(coef(logregp1u) [2])

#########
# participant 2u
# fit logistic regression model.
logregp2u <- glm(answer ~ step, family=binomial(link="logit"), data=p2u)

# define new data frame that contains predictor variable
logregp2uframe <- data.frame(step=seq(min(p2u$step), max(p2u$step), len=500))

# use fitted model to predict values of dependent variables
logregp2uframe$answer = predict(logregp2u, logregp2uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p2u, col="steelblue")
lines(answer ~ step, logregp2uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp2u) [1])/(coef(logregp2u) [2])

#########
# participant 3u
# fit logistic regression model.
logregp3u <- glm(answer ~ step, family=binomial(link="logit"), data=p3u)

# define new data frame that contains predictor variable
logregp3uframe <- data.frame(step=seq(min(p3u$step), max(p3u$step), len=500))

# use fitted model to predict values of dependent variables
logregp3uframe$answer = predict(logregp3u, logregp3uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p3u, col="steelblue")
lines(answer ~ step, logregp3uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp3u) [1])/(coef(logregp3u) [2])

#########
# participant 6u
# fit logistic regression model.
logregp6u <- glm(answer ~ step, family=binomial(link="logit"), data=p6u)

# define new data frame that contains predictor variable
logregp6uframe <- data.frame(step=seq(min(p6u$step), max(p6u$step), len=500))

# use fitted model to predict values of dependent variables
logregp6uframe$answer = predict(logregp6u, logregp6uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p6u, col="steelblue")
lines(answer ~ step, logregp6uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp6u) [1])/(coef(logregp6u) [2])

#########
# participant 8u
# fit logistic regression model.
logregp8u <- glm(answer ~ step, family=binomial(link="logit"), data=p8u)

# define new data frame that contains predictor variable
logregp8uframe <- data.frame(step=seq(min(p8u$step), max(p8u$step), len=500))

# use fitted model to predict values of dependent variables
logregp8uframe$answer = predict(logregp8u, logregp8uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p8u, col="steelblue")
lines(answer ~ step, logregp8uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp8u) [1])/(coef(logregp8u) [2])

#########
# participant 10u
# fit logistic regression model.
logregp10u <- glm(answer ~ step, family=binomial(link="logit"), data=p10u)

# define new data frame that contains predictor variable
logregp10uframe <- data.frame(step=seq(min(p10u$step), max(p10u$step), len=500))

# use fitted model to predict values of dependent variables
logregp10uframe$answer = predict(logregp10u, logregp10uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p10u, col="steelblue")
lines(answer ~ step, logregp10uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp10u) [1])/(coef(logregp10u) [2])

#########
# participant 11u
# fit logistic regression model.
logregp11u <- glm(answer ~ step, family=binomial(link="logit"), data=p11u)

# define new data frame that contains predictor variable
logregp11uframe <- data.frame(step=seq(min(p11u$step), max(p11u$step), len=500))

# use fitted model to predict values of dependent variables
logregp11uframe$answer = predict(logregp11u, logregp11uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p11u, col="steelblue")
lines(answer ~ step, logregp11uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp11u) [1])/(coef(logregp11u) [2])

#########
# participant 12u
# fit logistic regression model.
logregp12u <- glm(answer ~ step, family=binomial(link="logit"), data=p12u)

# define new data frame that contains predictor variable
logregp12uframe <- data.frame(step=seq(min(p12u$step), max(p12u$step), len=500))

# use fitted model to predict values of dependent variables
logregp12uframe$answer = predict(logregp12u, logregp12uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p12u, col="steelblue")
lines(answer ~ step, logregp12uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp12u) [1])/(coef(logregp12u) [2])

#########
# participant 14u
# fit logistic regression model.
logregp14u <- glm(answer ~ step, family=binomial(link="logit"), data=p14u)

# define new data frame that contains predictor variable
logregp14uframe <- data.frame(step=seq(min(p14u$step), max(p14u$step), len=500))

# use fitted model to predict values of dependent variables
logregp14uframe$answer = predict(logregp14u, logregp14uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p14u, col="steelblue")
lines(answer ~ step, logregp14uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp14u) [1])/(coef(logregp14u) [2])

#########
# participant 17u
# fit logistic regression model.
logregp17u <- glm(answer ~ step, family=binomial(link="logit"), data=p17u)

# define new data frame that contains predictor variable
logregp17uframe <- data.frame(step=seq(min(p17u$step), max(p17u$step), len=500))

# use fitted model to predict values of dependent variables
logregp17uframe$answer = predict(logregp17u, logregp17uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p17u, col="steelblue")
lines(answer ~ step, logregp17uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp17u) [1])/(coef(logregp17u) [2])

#########
# participant 18u
# fit logistic regression model.
logregp18u <- glm(answer ~ step, family=binomial(link="logit"), data=p18u)

# define new data frame that contains predictor variable
logregp18uframe <- data.frame(step=seq(min(p18u$step), max(p18u$step), len=500))

# use fitted model to predict values of dependent variables
logregp18uframe$answer = predict(logregp18u, logregp18uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p18u, col="steelblue")
lines(answer ~ step, logregp18uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp18u) [1])/(coef(logregp18u) [2])

#########
# participant 19u
# fit logistic regression model.
logregp19u <- glm(answer ~ step, family=binomial(link="logit"), data=p19u)

# define new data frame that contains predictor variable
logregp19uframe <- data.frame(step=seq(min(p19u$step), max(p19u$step), len=500))

# use fitted model to predict values of dependent variables
logregp19uframe$answer = predict(logregp19u, logregp19uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p19u, col="steelblue")
lines(answer ~ step, logregp19uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp19u) [1])/(coef(logregp19u) [2])

#########
# participant 22u
# fit logistic regression model.
logregp22u <- glm(answer ~ step, family=binomial(link="logit"), data=p22u)

# define new data frame that contains predictor variable
logregp22uframe <- data.frame(step=seq(min(p22u$step), max(p22u$step), len=500))

# use fitted model to predict values of dependent variables
logregp22uframe$answer = predict(logregp22u, logregp22uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p22u, col="steelblue")
lines(answer ~ step, logregp22uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp22u) [1])/(coef(logregp22u) [2])

#########
# participant 26u
# fit logistic regression model.
logregp26u <- glm(answer ~ step, family=binomial(link="logit"), data=p26u)

# define new data frame that contains predictor variable
logregp26uframe <- data.frame(step=seq(min(p26u$step), max(p26u$step), len=500))

# use fitted model to predict values of dependent variables
logregp26uframe$answer = predict(logregp26u, logregp26uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p26u, col="steelblue")
lines(answer ~ step, logregp26uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp26u) [1])/(coef(logregp26u) [2])

#########
# participant 27u
# fit logistic regression model.
logregp27u <- glm(answer ~ step, family=binomial(link="logit"), data=p27u)

# define new data frame that contains predictor variable
logregp27uframe <- data.frame(step=seq(min(p27u$step), max(p27u$step), len=500))

# use fitted model to predict values of dependent variables
logregp27uframe$answer = predict(logregp27u, logregp27uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p27u, col="steelblue")
lines(answer ~ step, logregp27uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp27u) [1])/(coef(logregp27u) [2])

#########
# participant 30u
# fit logistic regression model.
logregp30u <- glm(answer ~ step, family=binomial(link="logit"), data=p30u)

# define new data frame that contains predictor variable
logregp30uframe <- data.frame(step=seq(min(p30u$step), max(p30u$step), len=500))

# use fitted model to predict values of dependent variables
logregp30uframe$answer = predict(logregp30u, logregp30uframe, type="response")

# plot log reg curve
plot(answer ~ step, data=p30u, col="steelblue")
lines(answer ~ step, logregp30uframe, lwd=2)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregp30u) [1])/(coef(logregp30u) [2])

#################################
#################################
#################################
# run logistic regression on group N data for [i]
# fit logistic regression model.
logregENGgrNi <- glm(answer ~ step, family=binomial(link="logit"), data=ENGgrNi)

# define new data frame that contains predictor variable
logregENGgrNiframe <- data.frame(step=seq(min(ENGgrNi$step), max(ENGgrNi$step), len=500))

# use fitted model to predict values of dependent variables
logregENGgrNiframe$answer = predict(logregENGgrNi, logregENGgrNiframe, type="response")

# plot log reg curve
plot(answer ~ step, data=ENGgrNi, col="steelblue")
lines(answer ~ step, logregENGgrNiframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregENGgrNi)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregENGgrNi) [1])/(coef(logregENGgrNi) [2])
#################################


#################################
# run logistic regression on group N data for [u]
# fit logistic regression model.
logregENGgrNu <- glm(answer ~ step, family=binomial(link="logit"), data=ENGgrNu)

# define new data frame that contains predictor variable
logregENGgrNuframe <- data.frame(step=seq(min(ENGgrNu$step), max(ENGgrNu$step), len=500))

# use fitted model to predict values of dependent variables
logregENGgrNuframe$answer = predict(logregENGgrNu, logregENGgrNuframe, type="response")

# plot log reg curve
plot(answer ~ step, data=ENGgrNu, col="steelblue")
lines(answer ~ step, logregENGgrNuframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregENGgrNu)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregENGgrNu) [1])/(coef(logregENGgrNu) [2])
#################################


#################################
#################################
#################################
# run logistic regression on group H data for [i]
# fit logistic regression model.
logregENGgrHi <- glm(answer ~ step, family=binomial(link="logit"), data=ENGgrHi)

# define new data frame that contains predictor variable
logregENGgrHiframe <- data.frame(step=seq(min(ENGgrHi$step), max(ENGgrHi$step), len=500))

# use fitted model to predict values of dependent variables
logregENGgrHiframe$answer = predict(logregENGgrHi, logregENGgrHiframe, type="response")

# plot log reg curve
plot(answer ~ step, data=ENGgrHi, col="steelblue")
lines(answer ~ step, logregENGgrHiframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregENGgrHi)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregENGgrHi) [1])/(coef(logregENGgrHi) [2])
#################################


#################################
# run logistic regression on group H data for [u]
# fit logistic regression model.
logregENGgrHu <- glm(answer ~ step, family=binomial(link="logit"), data=ENGgrHu)

# define new data frame that contains predictor variable
logregENGgrHuframe <- data.frame(step=seq(min(ENGgrHu$step), max(ENGgrHu$step), len=500))

# use fitted model to predict values of dependent variables
logregENGgrHuframe$answer = predict(logregENGgrHu, logregENGgrHuframe, type="response")

# plot log reg curve
plot(answer ~ step, data=ENGgrHu, col="steelblue")
lines(answer ~ step, logregGERgruframe, lwd=2)

# generate slope value for logistic regression curve
coefficients(logregENGgrHu)

# calculate precise location of category boundary when y = 0.5
(log(1) - coef(logregENGgrHu) [1])/(coef(logregENGgrHu) [2])
#################################
#################################
#################################
#################################
#################################
#################################
#################################
